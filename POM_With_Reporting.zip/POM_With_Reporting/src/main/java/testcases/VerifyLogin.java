package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class VerifyLogin extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setDetails() {
		excelFileName = "Login";
		testName = "LoginAndLogout";
		testDescription = "LeafTaps login";
		author = "Hari";
		category = "smoke";

	}
		
	@Test(dataProvider = "sendData")
	public void runLogin(String username, String password) throws InterruptedException, IOException {
		
		//System.out.println(driver);
	
		new LoginPage(driver,prop)
		.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton()
		.verifyHomePage();
		
	}
	

	
	

}
