package pages;


import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.Then;

public class HomePage extends ProjectSpecificMethods {
	

	public MyHomePage clickCrmsfa() {
		driver.findElementByLinkText("CRM/SFA").click();
		return new MyHomePage();

	}

	public LoginPage clickLogout() {
		driver.findElementByClassName("decorativeSubmit").click();
		return new LoginPage();
	}

	@Then("CRMSFA link should be displayed")
	public HomePage verifyHomePage() {
		boolean displayed = driver.findElementByLinkText("CRM/SFA").isDisplayed();
		Assert.assertTrue(displayed);
		return this;

	}

}
