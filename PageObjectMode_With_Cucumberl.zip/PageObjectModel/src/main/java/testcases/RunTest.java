package testcases;

import base.ProjectSpecificMethods;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = "src/main/java/features/Login.feature", glue = {"base","pages"}, monochrome = true)
public class RunTest extends ProjectSpecificMethods{

}
