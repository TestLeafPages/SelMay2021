package pages;

import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class ViewLeadPage extends ProjectSpecificMethods {
	public ViewLeadPage(ChromeDriver driver) {
		this.driver = driver;

	}
	
	public ViewLeadPage verifyFirstName() {
		boolean displayed = driver.findElementById("viewLead_firstName_sp").isDisplayed();
		Assert.assertTrue(displayed);
		return this;
	}
	

}
